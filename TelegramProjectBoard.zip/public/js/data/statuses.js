// public/js/data/statuses.js

/**
 * Единый источник данных для статусов задач.
 * Содержит название, иконку и порядок сортировки.
 * Чем меньше 'order', тем выше будет группа в списке.
 */
export const STATUSES = [
    { name: 'В работе',     icon: '🛠️', order: 1 },
    { name: 'К выполнению', icon: '📥', order: 2 },
    { name: 'На контроле',  icon: '🔍', order: 3 },
    { name: 'Отложено',     icon: '⏳', order: 4 },
    { name: 'Выполнено',    icon: '✔️', order: 5 }
];