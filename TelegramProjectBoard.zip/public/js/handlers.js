import * as api from './api.js';
import * as render from './ui/render.js';
import * as modals from './ui/modals.js';
import * as uiUtils from './ui/utils.js';
import * as store from './store.js';
import { STATUSES } from './data/statuses.js';

export async function handleSaveActiveTask() {
    const tg = window.Telegram.WebApp;
    const activeEditElement = document.querySelector('.task-details.edit-mode');
    if (!activeEditElement) return;

    const appData = store.getAppData();
    const responsibleText = activeEditElement.querySelector('.task-responsible-view').textContent;
    const selectedEmployees = responsibleText ? responsibleText.split(',').map(s => s.trim()).filter(Boolean) : [];
    
    const { task: taskInAppData } = store.findTask(activeEditElement.querySelector('.task-row-index').value);
    if (!taskInAppData) {
        tg.showAlert('Не удалось найти исходную задачу для сохранения.');
        return;
    }

    const updatedTask = {
        ...taskInAppData,
        name: activeEditElement.querySelector('.task-name-edit').value,
        message: activeEditElement.querySelector('.task-message-edit').value,
        status: activeEditElement.querySelector('.task-status-view').textContent,
        project: activeEditElement.querySelector('.task-project-view').textContent,
        responsible: selectedEmployees,
        version: parseInt(activeEditElement.dataset.version, 10),
    };

    try {
        const result = await api.saveTask({taskData: updatedTask, modifierName: appData.userName});
        if (result.status === 'success') {
            uiUtils.showToast('Изменения сохранены', 'success');
            tg.HapticFeedback.notificationOccurred('success');
            Object.assign(taskInAppData, updatedTask, {version: result.newVersion});
            
            activeEditElement.dataset.task = JSON.stringify(taskInAppData).replace(/'/g, '&apos;');
            activeEditElement.dataset.version = result.newVersion;

            uiUtils.exitEditMode(activeEditElement);
            uiUtils.updateFabButtonUI(false, handleSaveActiveTask, handleShowAddTaskModal);
            render.renderProjects(appData.projects, appData.userName, appData.userRole);
        } else {
            if (result.error && result.error.includes("изменены другим пользователем")) {
                tg.showAlert(result.error + '\nТекущие данные будут обновлены.', () => window.location.reload());
            } else {
                tg.showAlert('Ошибка сохранения: ' + (result.error || 'Неизвестная ошибка'));
            }
        }
    } catch (error) {
        tg.showAlert('Критическая ошибка сохранения: ' + error.message);
    }
}

export function handleShowAddTaskModal() {
    const appData = store.getAppData();
    modals.openAddTaskModal(store.getAllProjects(), store.getAllEmployees(), appData.userRole, appData.userName);
    // Меняем FAB-кнопку на "Сохранить" и назначаем ей новый обработчик
    uiUtils.updateFabButtonUI(true, handleSaveNewTaskClick);
}

export async function handleCreateTask(taskData) {
    const tg = window.Telegram.WebApp;
    const appData = store.getAppData();
    
    const allTasksForScope = (appData.userRole === 'user')
        ? appData.projects.flatMap(p => p.tasks)
        : (appData.projects.find(p => p.name === taskData.project) || {tasks: []}).tasks;

    const tasksInGroup = allTasksForScope.filter(t => t.status === taskData.status);
    const maxPriority = Math.max(0, ...tasksInGroup.map(t => t.priority));
    taskData.priority = maxPriority + 1;
    
    const tempRowIndex = `temp_${Date.now()}`;
    const optimisticTask = { ...taskData, rowIndex: tempRowIndex, version: 0 };
    let targetProject = appData.projects.find(p => p.name === optimisticTask.project);
    if (!targetProject) {
        targetProject = { name: optimisticTask.project, tasks: [] };
        appData.projects.push(targetProject);
    }
    targetProject.tasks.push(optimisticTask);
    modals.closeAddTaskModal();
    render.renderProjects(appData.projects, appData.userName, appData.userRole);
    uiUtils.showToast('Задача добавлена, идет сохранение...');
    tg.HapticFeedback.notificationOccurred('success');
    try {
        const result = await api.addTask({newTaskData: taskData, creatorName: appData.userName});
        if (result.status === 'success' && result.task) {
            const finalTask = result.task;
            const taskToUpdate = targetProject.tasks.find(t => t.rowIndex === tempRowIndex);
            if (taskToUpdate) Object.assign(taskToUpdate, finalTask);
            render.renderProjects(appData.projects, appData.userName, appData.userRole);
            uiUtils.showToast('Задача успешно сохранена', 'success');
        } else {
            throw new Error(result.error || 'Неизвестная ошибка сервера');
        }
    } catch (error) {
        tg.showAlert(`Не удалось сохранить задачу: ${error.message}. Обновляем список...`);
        window.location.reload();
    }
}

export async function handleStatusUpdate(rowIndex, newStatus) {
    const tg = window.Telegram.WebApp;
    const appData = store.getAppData();
    const { task, project } = store.findTask(rowIndex);
    if (!task || !project) return;
    
    const oldStatus = task.status;
    const oldPriority = task.priority;
    
    const allTasksForScope = (appData.userRole === 'user') 
        ? appData.projects.flatMap(p => p.tasks)
        : project.tasks;
    
    task.status = newStatus;
    
    if (newStatus === 'Выполнено') {
        task.priority = 999;
    } else {
        const tasksInNewGroup = allTasksForScope.filter(t => t.status === newStatus && t.rowIndex !== task.rowIndex);
        const maxPriority = Math.max(0, ...tasksInNewGroup.map(t => t.priority));
        task.priority = maxPriority + 1;
    }
    const tasksInOldGroup = allTasksForScope.filter(t => t.status === oldStatus);
    tasksInOldGroup.sort((a, b) => a.priority - b.priority).forEach((t, index) => {
        t.priority = index + 1;
    });

    render.renderProjects(appData.projects, appData.userName, appData.userRole);
    uiUtils.showToast('Статус обновлён, идет сохранение...');
    
    const tasksToUpdate = [...tasksInOldGroup, task].map(t => ({
        rowIndex: t.rowIndex,
        priority: t.priority,
        status: t.status
    }));
    try {
        const result = await api.updatePriorities({tasks: tasksToUpdate, modifierName: appData.userName});
        if (result.status !== 'success') throw new Error(result.error || 'Ошибка сохранения');
        uiUtils.showToast('Сохранение завершено', 'success');
    } catch (error) {
        tg.showAlert('Не удалось сохранить изменения: ' + error.message);
        task.status = oldStatus;
        task.priority = oldPriority;
        window.location.reload();
    }
}

export function handleDragDrop(groupName, updatedTaskIdsInGroup, userRole) {
    const appData = store.getAppData();
    let tasksForScope;

    if (userRole === 'user' || userRole === 'gap') {
        tasksForScope = appData.projects.flatMap(p => p.tasks);
    } else {
        const projectData = appData.projects.find(p => p.name === groupName);
        if (!projectData) {
            console.error(`[handleDragDrop] Проект "${groupName}" не найден!`);
            return;
        }
        tasksForScope = projectData.tasks;
    }

    const taskMap = new Map(tasksForScope.map(t => [t.rowIndex.toString(), t]));

    const tasksToUpdate = updatedTaskIdsInGroup.map((id, index) => {
        const task = taskMap.get(id);
        if (task) {
            task.priority = index + 1;
            return { rowIndex: task.rowIndex, priority: task.priority };
        }
    }).filter(Boolean);

    // --- ИЗМЕНЕНИЕ: УДАЛЯЕМ ЛИШНЮЮ ПЕРЕРИСОВКУ ---
    // render.renderProjects(appData.projects, appData.userName, appData.userRole);
    
    uiUtils.showToast('Идет сохранение нового порядка задач...');
    
    api.updatePriorities({tasks: tasksToUpdate, modifierName: appData.userName})
        .then(result => {
            if (result.status === 'success') {
                uiUtils.showToast('Сохранение завершено', 'success');
            } else {
                throw new Error(result.error || 'Неизвестная ошибка сервера');
            }
        })
        .catch(error => {
            window.Telegram.WebApp.showAlert('Не удалось сохранить новый порядок задач: ' + error.message);
            window.location.reload();
        });
}

// Ваша отладочная функция
function print (message) {
    window.Telegram.WebApp.showAlert(JSON.stringify(message, null, 2), 'OK'); 
}

/**
 * Вызывается при нажатии на FAB-кнопку "Сохранить"
 * для новой, еще не созданной задачи.
 */
export function handleSaveNewTaskClick() {
    const tg = window.Telegram.WebApp;
    const appData = store.getAppData();
    
    const taskName = document.getElementById('new-task-name')?.value;
    const projectName = document.getElementById('new-task-project')?.value;
    const message = document.getElementById('new-task-message')?.value;
    const activeStatusElement = document.querySelector('#new-task-status-toggle .toggle-option.active');
    const status = activeStatusElement ? activeStatusElement.dataset.status : 'К выполнению';

    let responsibleNames = [];
    if (appData.userRole === 'user') {
        responsibleNames = [appData.userName];
    } else {
        const responsibleCheckboxes = document.querySelectorAll('#add-task-modal .employee-checkbox:checked');
        responsibleNames = [...responsibleCheckboxes].map(cb => cb.value);
    }

    if (!taskName || !projectName || (appData.userRole !== 'user' && responsibleNames.length === 0)) {
        return tg.showAlert('Пожалуйста, заполните поля: Наименование, Проект и Ответственный.');
    }

    const allEmployees = store.getAllEmployees();
    const responsibleUsers = allEmployees.filter(emp => responsibleNames.includes(emp.name));
    const responsibleUserIds = responsibleUsers.map(emp => emp.userId);

    handleCreateTask({
        name: taskName,
        project: projectName,
        status: status,
        responsible: responsibleNames.join(', '),
        message: message,
        creatorId: window.currentUserId,
        responsibleUserIds: responsibleUserIds
    });
}